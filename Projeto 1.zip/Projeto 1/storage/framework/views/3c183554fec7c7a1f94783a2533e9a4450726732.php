<!DOCTYPE html> 
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Produtos</title>

        <link rel="stylesheet" href="/css/styles.css">
    </head>
    <body>
        <header>
           <nav>
                <ul>
                    <li>Home</li>
                    <li>Buy</li>
                    <li>Cart</li>
                </ul>
           </nav> 
           <section>
                <div class="item">
                    <div class="img-head">
                        <img src="img/cms1.jpg">
                    </div> 
                    <div class="description">
                        <p style="color: red; text-shadow: 0 0 0.2em black, 0 0 0.2em black,
        0 0 0.2em black;">Quick, only <?php echo e($products[0]->count); ?> left!</p>
                        <p><?php echo e($products[0]->description); ?></p>
                    </div>
                    <div class="footer">
                        <button type="button">Buy</button>
                        <div class="price"><p>$<?php echo e($products[0]->price); ?></p></div>
                    </div>
                </div>
                <div class="item">
                    <div class="img-head">
                        <img src="img/cms2.jpg">
                    </div>
                    <div class="description">
                    <p style="color: red; text-shadow: 0 0 0.2em black, 0 0 0.2em black,
        0 0 0.2em black;">Quick, only <?php echo e($products[1]->count); ?> left!</p>
                        <p><?php echo e($products[1]->description); ?><p>
                    </div>
                    <div class="footer">
                        <button type="button">Buy</button>
                        <div class="price"><p>$<?php echo e($products[1]->price); ?></p></div>
                    </div>
                </div>
                <div class="item">
                    <div class="img-head">
                        <img src="img/cms3.jpg">  
                    </div>
                    <div class="description">
                    <p style="color: red; text-shadow: 0 0 0.2em black, 0 0 0.2em black,
        0 0 0.2em black;">Quick, only <?php echo e($products[2]->count); ?> left!</p>
                        <p><?php echo e($products[2]->description); ?></p>
                    </div>
                    <div class="footer">
                        <button type="button">Buy</button>
                        <div class="price"><p>$<?php echo e($products[2]->price); ?></p></div>
                    </div>
                </div>
           </section>
           <footer>

           </footer>
        </header>
    </body>
    <footer>
        <p>Projeto de programação WEB - MVC com Laravel</p>
    </footer>
</html><?php /**PATH C:\xampp\htdocs\pweb-project\resources\views/produtos.blade.php ENDPATH**/ ?>