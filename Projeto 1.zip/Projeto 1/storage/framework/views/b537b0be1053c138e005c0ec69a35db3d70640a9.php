<!DOCTYPE html> 
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Teste</title>
    </head>
    <body>
        <a href="/teste/<?php echo e($teste->id); ?>" class="btn">click teste</a>
    </body>
    <footer>

    </footer>

</html><?php /**PATH C:\xampp\htdocs\pweb-project\resources\views/teste.blade.php ENDPATH**/ ?>