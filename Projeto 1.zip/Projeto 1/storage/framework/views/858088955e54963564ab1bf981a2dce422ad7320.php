<!DOCTYPE html> 
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Produtos</title>

        <link rel="stylesheet" href="/css/styles.css">
    </head>
    <body>
        <header>
           <nav>
                <ul>
                    <li></li>
                    <li>VATech - sua melhor loja de acessórios</li>
                    <li></li>
                </ul>
           </nav> 
           <section>
                <div class="item">
                    <div class="img-head">
                        <img src="img/Cap1.jpg">
                    </div> 
                    <div class="description">
                      <p style="color: blue;">Somente <?php echo e($products[0]->count); ?> unidades restantes!</p>
                        <p><?php echo e($products[0]->description); ?></p> <p>R$<?php echo e($products[0]->price); ?>,00</p> 
                    </div>
                    <div class="footer">
                        <button type="button">Comprar</button>
                       
                    </div>
                </div>
                <div class="item">
                    <div class="img-head">
                        <img src="img/Fones.jpg">
                    </div>
                    <div class="description">
                        <p style="color: blue; ">Somente <?php echo e($products[1]->count); ?> unidades restantes!</p>
                        <p><?php echo e($products[1]->description); ?></p> <p>R$<?php echo e($products[1]->price); ?>,00</p>
    
                    </div>
                    <div class="footer">
                        <button type="button">Comprar</button>
                       
                    </div>
                </div>
                <div class="item">
                    <div class="img-head">
                        <img src="img/Pel.jpg">  
                    </div>
                    <div class="description">
                    <p style="color: blue;">Somente <?php echo e($products[2]->count); ?> unidades restantes!</p>
                        <p><?php echo e($products[2]->description); ?></p> <p>R$<?php echo e($products[2]->price); ?>,00</p>
                    </div>
                    <div class="footer">
                        <button type="button">Comprar</button>
                        
                    </div>
                </div>
           </section>
           <footer>

           </footer>
        </header>
    </body>
    <footer>
        <p>Ana Flávia | Keven Kolberg</p>
    </footer>
</html><?php /**PATH C:\xampp\htdocs\Projeto 1\resources\views/produtos.blade.php ENDPATH**/ ?>