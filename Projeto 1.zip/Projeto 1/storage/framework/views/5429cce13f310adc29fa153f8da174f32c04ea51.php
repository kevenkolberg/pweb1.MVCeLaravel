<!DOCTYPE html> 
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Teste</title>
    </head>
    <body>
        <h1>View products com id: <?php echo e($id); ?></h1>
    </body>
    <footer>

    </footer>

</html><?php /**PATH C:\xampp\htdocs\pweb-project\resources\views/product.blade.php ENDPATH**/ ?>